# Overview

This is a real-time chat application built with React, Express, and PostgreSQL. The application features a modern UI with a literary theme, allowing users to create accounts and participate in chat conversations. It uses a full-stack TypeScript architecture with shared schemas between frontend and backend, real-time message updates, and a comprehensive UI component library built with Radix UI and Tailwind CSS.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Library**: Comprehensive component system built on Radix UI primitives with shadcn/ui styling
- **Styling**: Tailwind CSS with custom literary-themed design tokens and CSS variables
- **Real-time Updates**: Custom polling-based approach for message synchronization

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **API Design**: RESTful API with structured error handling and request logging
- **Data Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **Development Server**: Integrated Vite development server with HMR support
- **Build Process**: ESBuild for server bundling with external package optimization

## Database Schema
- **Users Table**: UUID primary keys, unique usernames, and timestamp tracking
- **Messages Table**: UUID primary keys with foreign key relationships to users, content storage, and denormalized username for performance
- **Schema Management**: Drizzle ORM with PostgreSQL dialect and Zod validation integration

## Authentication & Authorization
- **User Management**: Simple username-based registration without passwords
- **Session Handling**: Client-side user persistence via localStorage
- **Data Validation**: Comprehensive input validation using Zod schemas shared between client and server

## Real-time Communication
- **Message Updates**: Polling-based approach with 1-second intervals for new message detection
- **Connection Status**: Visual indicators for real-time connection state
- **Typing Indicators**: Framework for showing user typing status (placeholder implementation)

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL with connection pooling via @neondatabase/serverless
- **Drizzle ORM**: Type-safe database queries with automatic migration support
- **Connection Management**: Environment-based database URL configuration with connection validation

## UI Components
- **Radix UI**: Comprehensive primitive component library for accessibility and behavior
- **Tailwind CSS**: Utility-first CSS framework with custom design system integration
- **Lucide React**: Modern icon library with consistent styling
- **Date-fns**: Date manipulation and formatting utilities

## Development Tools
- **Vite**: Fast build tool with React plugin and development server integration
- **TypeScript**: Full-stack type safety with shared type definitions
- **ESBuild**: Fast JavaScript bundler for production server builds
- **Replit Integration**: Runtime error overlay and cartographer plugins for development environment

## Form & Validation
- **React Hook Form**: Form state management with validation integration
- **Zod**: Runtime type validation with automatic TypeScript type inference
- **Hookform Resolvers**: Integration layer between React Hook Form and Zod validation

## Styling & Theming
- **Class Variance Authority**: Type-safe component variant management
- **clsx**: Conditional CSS class name utility
- **Tailwind Merge**: Intelligent Tailwind class merging for component composition