import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import type { Message } from "@shared/schema";

interface RealtimeOptions {
  onInsert?: (payload: any) => void;
  onUpdate?: (payload: any) => void;
  onDelete?: (payload: any) => void;
}

export function useRealtime(table: string, options: RealtimeOptions = {}) {
  const { onInsert } = options;
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const queryClient = useQueryClient();
  const lastMessageCountRef = useRef<number>(0);

  useEffect(() => {
    const checkForNewMessages = async () => {
      try {
        // Get current messages from cache
        const currentMessages = queryClient.getQueryData<Message[]>(["/api/messages"]) || [];
        
        if (currentMessages.length > lastMessageCountRef.current) {
          // New messages detected
          const newMessages = currentMessages.slice(lastMessageCountRef.current);
          newMessages.forEach(message => {
            if (onInsert) {
              onInsert(message);
            }
          });
        }
        
        lastMessageCountRef.current = currentMessages.length;
      } catch (error) {
        console.error("Realtime polling error:", error);
      }
    };

    // Check for new messages every 2 seconds
    intervalRef.current = setInterval(checkForNewMessages, 2000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [table, onInsert, queryClient]);

  return {
    isConnected: true,
  };
}
