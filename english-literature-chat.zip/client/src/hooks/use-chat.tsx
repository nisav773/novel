import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRealtime } from "./use-realtime";
import { apiRequest } from "@/lib/queryClient";
import type { Message, User } from "@shared/schema";

export function useChat() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const queryClient = useQueryClient();

  // Load user from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem("chat-user");
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  // Fetch messages
  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    enabled: !!currentUser,
  });

  // Real-time subscription for new messages
  const { isConnected } = useRealtime("messages", {});

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!currentUser) throw new Error("No user set");
      
      const response = await apiRequest("POST", "/api/messages", {
        content,
        userId: currentUser.id,
        username: currentUser.username,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
    },
  });

  // Set username mutation
  const setUsernameMutation = useMutation({
    mutationFn: async (username: string) => {
      const response = await apiRequest("POST", "/api/users", { username });
      return response.json();
    },
    onSuccess: (user: User) => {
      setCurrentUser(user);
      localStorage.setItem("chat-user", JSON.stringify(user));
    },
  });

  const sendMessage = useCallback((content: string) => {
    if (!content.trim() || !currentUser) return;
    sendMessageMutation.mutate(content);
  }, [currentUser, sendMessageMutation]);

  const setUsername = useCallback((username: string) => {
    if (!username.trim()) return;
    setUsernameMutation.mutate(username);
  }, [setUsernameMutation]);

  return {
    messages,
    currentUser,
    isLoading,
    isConnected,
    typingUsers,
    sendMessage,
    setUsername,
    isSending: sendMessageMutation.isPending,
    isSettingUsername: setUsernameMutation.isPending,
  };
}
