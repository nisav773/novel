import { useEffect, useRef } from "react";
import { MessageItem } from "./message-item";
import { TypingIndicator } from "./typing-indicator";
import type { Message, User } from "@shared/schema";

interface MessageListProps {
  messages: Message[];
  currentUser: User | null;
  typingUsers: string[];
}

export function MessageList({ messages, currentUser, typingUsers }: MessageListProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div 
      ref={containerRef}
      className="flex-1 overflow-y-auto p-4 space-y-4" 
      data-testid="message-list"
    >
      {/* Welcome message */}
      <div className="flex justify-center">
        <div className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
          Welcome to English Literature chat room
        </div>
      </div>

      {/* Messages */}
      {messages.map((message) => (
        <MessageItem key={message.id} message={message} currentUser={currentUser} />
      ))}

      {/* Typing indicator */}
      <TypingIndicator users={typingUsers} />
    </div>
  );
}
