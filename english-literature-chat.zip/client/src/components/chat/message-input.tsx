import { useState, useRef, useEffect } from "react";
import { Send, Type, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

interface MessageInputProps {
  onSendMessage: (content: string) => void;
  onSetUsername: (username: string) => void;
  currentUser: any;
  isSending: boolean;
  isSettingUsername: boolean;
  isConnected: boolean;
}

export function MessageInput({ 
  onSendMessage, 
  onSetUsername, 
  currentUser, 
  isSending, 
  isSettingUsername,
  isConnected 
}: MessageInputProps) {
  const [messageInput, setMessageInput] = useState("");
  const [usernameInput, setUsernameInput] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [messageInput]);

  const handleSendMessage = () => {
    if (!messageInput.trim() || !currentUser || isSending) return;
    onSendMessage(messageInput);
    setMessageInput("");
  };

  const handleSetUsername = () => {
    if (!usernameInput.trim() || isSettingUsername) return;
    onSetUsername(usernameInput);
    setUsernameInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleUsernameKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSetUsername();
    }
  };

  return (
    <div className="border-t border-gray-200 bg-white">
      {/* User Setup Section */}
      {!currentUser && (
        <div className="px-4 py-3 bg-parchment-light border-b border-gray-200" data-testid="user-setup">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center space-x-3">
              <Type className="text-literary-brown" />
              <div className="flex-1">
                <Input
                  type="text"
                  placeholder="Enter your pen name to join the discussion..."
                  className="w-full"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  onKeyDown={handleUsernameKeyPress}
                  maxLength={50}
                  data-testid="input-username"
                />
              </div>
              <Button
                onClick={handleSetUsername}
                disabled={!usernameInput.trim() || isSettingUsername}
                className="bg-literary-brown hover:bg-literary-brown/90"
                data-testid="button-join-chat"
              >
                {isSettingUsername ? "Joining..." : "Join Chat"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Message Input Section */}
      <div className="px-4 py-4">
        <div className="max-w-4xl mx-auto">
          {/* Connection Error State */}
          {!isConnected && (
            <div className="mb-3 p-3 bg-crimson/10 border border-crimson/20 rounded-lg" data-testid="connection-error">
              <div className="flex items-center space-x-2 text-crimson">
                <AlertTriangle size={16} />
                <span className="text-sm font-medium">Connection lost. Attempting to reconnect...</span>
              </div>
            </div>
          )}

          <div className="flex items-end space-x-3">
            <div className="flex-1">
              <Textarea
                ref={textareaRef}
                placeholder="Share your literary thoughts..."
                className="resize-none border-2 border-gray-200 focus:border-literary-brown min-h-[44px]"
                rows={1}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={handleKeyPress}
                maxLength={1000}
                disabled={!currentUser || !isConnected}
                data-testid="input-message"
              />
              <div className="flex items-center justify-between mt-2 px-1">
                <div className="flex items-center space-x-4 text-xs text-gray-500">
                  <span data-testid="text-character-count">{messageInput.length}/1000</span>
                  <span className="text-gray-400">Press Enter to send, Shift+Enter for new line</span>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col space-y-2">
              <Button
                onClick={handleSendMessage}
                disabled={!messageInput.trim() || !currentUser || isSending || !isConnected}
                className="w-12 h-12 bg-literary-brown hover:bg-literary-brown/90 p-0"
                title="Send message"
                data-testid="button-send"
              >
                <Send size={18} />
              </Button>
              
              <Button
                variant="outline"
                className="w-12 h-12 p-0"
                title="Formatting options"
                data-testid="button-formatting"
              >
                <Type size={14} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
