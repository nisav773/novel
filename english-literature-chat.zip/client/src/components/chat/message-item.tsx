import { format } from "date-fns";
import type { Message, User } from "@shared/schema";

interface MessageItemProps {
  message: Message;
  currentUser: User | null;
}

export function MessageItem({ message, currentUser }: MessageItemProps) {
  const isOwn = currentUser?.id === message.userId;
  const timestamp = format(new Date(message.createdAt), 'h:mm a');

  if (isOwn) {
    return (
      <div className="flex items-start space-x-3 max-w-4xl ml-auto flex-row-reverse" data-testid="message-sent">
        <div className="w-8 h-8 bg-literary-gold rounded-full flex items-center justify-center flex-shrink-0">
          <span className="text-xs font-semibold text-white">
            {message.username[0].toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline space-x-2 mb-1 flex-row-reverse">
            <span className="font-semibold text-sm text-literary-brown">You</span>
            <span className="text-xs text-gray-500">{timestamp}</span>
          </div>
          <div className="bg-parchment-sent border border-literary-brown/20 rounded-lg px-4 py-2 shadow-sm">
            <p className="text-sm leading-relaxed">{message.content}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-3 max-w-4xl" data-testid="message-received">
      <div className="w-8 h-8 bg-literary-brown rounded-full flex items-center justify-center flex-shrink-0">
        <span className="text-xs font-semibold text-white">
          {message.username[0].toUpperCase()}
        </span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline space-x-2 mb-1">
          <span className="font-semibold text-sm text-literary-brown">{message.username}</span>
          <span className="text-xs text-gray-500">{timestamp}</span>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg px-4 py-2 shadow-sm">
          <p className="text-sm leading-relaxed">{message.content}</p>
        </div>
      </div>
    </div>
  );
}
