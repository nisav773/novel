import { BookOpen } from "lucide-react";
import { ConnectionStatus } from "./connection-status";
import type { User } from "@shared/schema";

interface ChatHeaderProps {
  currentUser: User | null;
  isConnected: boolean;
}

export function ChatHeader({ currentUser, isConnected }: ChatHeaderProps) {
  return (
    <header className="bg-white border-b-2 border-literary-brown shadow-sm px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-literary-brown rounded-lg flex items-center justify-center">
          <BookOpen className="text-white text-lg" />
        </div>
        <div>
          <h1 className="font-literary font-bold text-xl text-literary-brown">
            English Literature
          </h1>
          <p className="text-sm text-gray-600 font-medium">Chapter Room</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <ConnectionStatus isConnected={isConnected} />
        
        {currentUser && (
          <div className="flex items-center space-x-2 bg-parchment-light px-3 py-1 rounded-full" data-testid="current-user">
            <div className="w-6 h-6 bg-literary-gold rounded-full flex items-center justify-center">
              <span className="text-xs font-semibold text-white">
                {currentUser.username[0].toUpperCase()}
              </span>
            </div>
            <span className="text-sm font-medium">{currentUser.username}</span>
          </div>
        )}
      </div>
    </header>
  );
}
