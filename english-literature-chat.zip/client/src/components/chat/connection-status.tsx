interface ConnectionStatusProps {
  isConnected: boolean;
}

export function ConnectionStatus({ isConnected }: ConnectionStatusProps) {
  return (
    <div className="flex items-center space-x-2" data-testid="connection-status">
      <div 
        className={`w-2 h-2 rounded-full ${
          isConnected ? 'bg-forest animate-pulse' : 'bg-crimson'
        }`}
      />
      <span className={`text-sm font-medium ${
        isConnected ? 'text-forest' : 'text-crimson'
      }`}>
        {isConnected ? 'Connected' : 'Disconnected'}
      </span>
    </div>
  );
}
