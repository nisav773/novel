import { ChatHeader } from "@/components/chat/chat-header";
import { MessageList } from "@/components/chat/message-list";
import { MessageInput } from "@/components/chat/message-input";
import { useChat } from "@/hooks/use-chat";

export default function ChatPage() {
  const {
    messages,
    currentUser,
    isLoading,
    isConnected,
    typingUsers,
    sendMessage,
    setUsername,
    isSending,
    isSettingUsername,
  } = useChat();

  if (isLoading) {
    return (
      <div className="h-screen bg-parchment flex items-center justify-center">
        <div className="bg-white rounded-xl p-6 shadow-xl max-w-sm w-full mx-4">
          <div className="flex items-center space-x-3">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-literary-brown"></div>
            <div>
              <h3 className="font-literary font-semibold text-literary-brown">
                Connecting to the Library
              </h3>
              <p className="text-sm text-gray-600">Establishing real-time connection...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-parchment flex flex-col overflow-hidden">
      <ChatHeader currentUser={currentUser} isConnected={isConnected} />
      
      <div className="flex flex-col flex-1 min-h-0">
        <MessageList 
          messages={messages} 
          currentUser={currentUser} 
          typingUsers={typingUsers} 
        />
        
        <MessageInput
          onSendMessage={sendMessage}
          onSetUsername={setUsername}
          currentUser={currentUser}
          isSending={isSending}
          isSettingUsername={isSettingUsername}
          isConnected={isConnected}
        />
      </div>
    </div>
  );
}
